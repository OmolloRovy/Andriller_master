class FileHandlerError(Exception):
    pass
